package com.intersoft.occupancy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OccupancyApplication {

	public static void main(String[] args) {
		SpringApplication.run(OccupancyApplication.class, args);
	}

}
