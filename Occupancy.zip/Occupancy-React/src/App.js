import './App.css';
import OccupancyIs from './Components/occupancy';


function App() {
  return (
    <div className="App">
    <OccupancyIs />
    </div>
  );
}

export default App;
